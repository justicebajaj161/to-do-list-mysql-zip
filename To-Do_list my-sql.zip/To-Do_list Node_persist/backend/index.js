import express from 'express'
import cors from 'cors'
import mysql from 'mysql'





const app = express();
app.use(cors());
app.use(express.json());

const connection = mysql.createConnection({

  host:"localhost",
  user:"root",
  password:"",
  database:'tasks'

})

connection.connect(function(err){
  if(err){
      throw err;
  }

  console.log('connected');
})

app.post('/api/auth/postsale', async (req, res) => {
  console.log(req.body);
  connection.query(`insert into tasks(taskName) values("${req.body.data}");`)
  res.send('create task');
})

app.get('/api/auth/tasks', async (req, res) => {
  connection.query("select * from tasks", function (err, data) {
    if (err) 
    throw err;
    res.send(data);
  });
  })

app.post('/api/auth/delete/:id',async(req,res)=>{
console.log(req.params.id)
const id = req.params.id;
connection.query(`delete from tasks where id=${id}`,(err,res)=>{
    if(err) throw err
})
res.json({"msg":"deleted"});
})



const PORT = 8000;

app.listen(PORT,()=>{
    console.log(`running at port ${PORT}`)
});


