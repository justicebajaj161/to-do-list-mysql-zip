import axios from 'axios'

const URL=`http://localhost:8000`;

const enterTaskAxios=async(data)=>{
    console.log(data,'fromapi')
    try {
        return await axios.post(`${URL}/api/auth/postsale`,{data})
    } catch (error) {
        console.log('error api',error)
    }
}




const getTaskAxios=async()=>{
    
    try {
        return await axios.get(`${URL}/api/auth/tasks`)
    } catch (error) {
        console.log('error api',error)
    }
}


const deletetodoaxios=async(id)=>{
    try {
        return await axios.post(`${URL}/api/auth/delete/${id}`)
    } catch (error) {
        console.log('error api',error)
    }
}

export {enterTaskAxios,getTaskAxios,deletetodoaxios}