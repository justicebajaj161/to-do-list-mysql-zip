import logo from './logo.svg';
import './App.css';
import Tasks from './components/Tasks';

function App() {
  return (
  <>
  <Tasks/>
  </>
  );
}

export default App;
