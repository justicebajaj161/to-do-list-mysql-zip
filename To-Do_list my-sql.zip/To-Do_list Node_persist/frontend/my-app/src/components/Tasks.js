import React, { useEffect, useState } from 'react'
import { deletetodoaxios, enterTaskAxios, getTaskAxios } from '../apis/api'

const Tasks = () => {
  const [groceries , setGroceries]=useState('')
  const [getgroceries,setGetgroceries]=useState('')
  const handleTaskChange=(e)=>{
    setGroceries(e.target.value);
  }

  const submittast=async(e)=>{
    e.preventDefault();
    const response = await enterTaskAxios(groceries);
    gettasks();
  }

  useEffect(()=>{
    gettasks();
  },[])

  const gettasks=async()=>{
    const {data} = await getTaskAxios();
    console.log(data)
   
    
    setGetgroceries(data) 
  }

  const deletetodo=async(e)=>{
    console.log(e)
   const response=await deletetodoaxios(e)
   gettasks();
  }
console.log(getgroceries)
  return (
    <div>
            <div className="App">
     <div className='heading'><h1>To Do List App</h1></div>
     <br/>
     <div className='enter-task-show-tasks-box'>
      <div className='flex-input'>
      <div htmlFor="firstName" className='label'>Enter the tast:</div>
      
       <input className='input-tast' type="text"  onChange={handleTaskChange} placeholder='Get groceries' />
       <button className='button-insert-tast' onClick={submittast}>Add Task</button>
       
      </div>
      {getgroceries&&getgroceries.map((task)=>{
        return <>
          <br/>
     <div className='all-tasks'>{task.taskName}<div className='delete' onClick={(e)=>deletetodo(task.id)}><i class="fa-regular fa-circle-xmark"></i></div></div>
       
        <br/>
        </>
      })}
   
     
     

     

     </div>
    </div>
    </div>
  )
}

export default Tasks
